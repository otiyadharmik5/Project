# Backend-Frontend Assignment (Full Project)

## Overview
This repository contains a simple backend (Node.js + Express + MongoDB) and a frontend (React + Vite) to demo:
- User registration & login (JWT)
- Role-based access (user/admin)
- CRUD for tasks
- Simple frontend to interact with the APIs

## Prereqs
- Node.js (v18+ recommended)
- MongoDB (local or remote)

## Setup - Backend
1. Open terminal and go to backend folder:
```bash
cd backend
cp .env.example .env
# edit .env and set JWT_SECRET and MONGO_URI
npm install
npm run dev
```
Server will run at http://localhost:5000 by default.

## Setup - Frontend
```bash
cd frontend
npm install
npm run dev
```
Frontend (Vite) will run on http://localhost:5173 by default. It expects backend at http://localhost:5000/api/v1 (change VITE_API_BASE if needed).

## Notes
- This is a starter project for the assignment. For production-readiness: use httpOnly cookies for JWTs, add rate-limiting, input sanitization, tests, and Dockerfiles.
