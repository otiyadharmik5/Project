Short scalability notes:

1) Split services: auth-service, task-service (separate DBs or schemas).
2) Use Redis for caching frequently read endpoints (e.g., list tasks for admin).
3) Add rate-limiting and request throttling.
4) Containerize with Docker; compose for local dev.
5) Use a load balancer (NGINX) and run multiple instances behind it.
6) Use managed DB (Atlas/RDS) and enable backups & read replicas.
