import React, { useEffect, useState } from 'react'
import { get, post, put, del } from '../api/api'

export default function Dashboard({ token }) {
  const [tasks, setTasks] = useState([]);
  const [form, setForm] = useState({ title: '', description: '' });
  const [msg, setMsg] = useState('');

  const load = async () => {
    const res = await get('/tasks', token);
    setTasks(res || []);
  }

  useEffect(() => { if (token) load(); }, [token]);

  const add = async (e) => {
    e.preventDefault();
    const r = await post('/tasks', form, token);
    if (r._id) { setForm({ title: '', description: '' }); load(); }
    else setMsg(r.message || JSON.stringify(r));
  }

  const toggle = async (t) => {
    await put('/tasks/'+t._id, { completed: !t.completed }, token);
    load();
  }

  const remove = async (t) => {
    await del('/tasks/'+t._id, token);
    load();
  }

  if (!token) return <div>Please login to see dashboard.</div>

  return (
    <div>
      <h3>Dashboard</h3>
      <form onSubmit={add}>
        <input placeholder="Title" value={form.title} onChange={e=>setForm({...form,title:e.target.value})} />
        <input placeholder="Description" value={form.description} onChange={e=>setForm({...form,description:e.target.value})} />
        <button type="submit">Add</button>
      </form>
      <div>{msg}</div>
      <ul>
        {tasks.map(t=> (
          <li key={t._id}>
            <b>{t.title}</b> - {t.description} - {t.completed? '✅': '❌'}
            <button onClick={()=>toggle(t)}>Toggle</button>
            <button onClick={()=>remove(t)}>Delete</button>
          </li>
        ))}
      </ul>
    </div>
  )
}
