import React, { useState } from 'react'
import { post } from '../api/api'

export default function Register({ onSuccess }) {
  const [form, setForm] = useState({ name: '', email: '', password: '' });
  const [msg, setMsg] = useState('');

  const submit = async (e) => {
    e.preventDefault();
    const res = await post('/auth/register', form);
    if (res.token) { onSuccess(res.token); }
    else setMsg(res.message || JSON.stringify(res));
  }

  return (
    <form onSubmit={submit} style={{ maxWidth: 400 }}>
      <h3>Register</h3>
      <input placeholder="Name" value={form.name} onChange={e => setForm({...form, name: e.target.value})} />
      <input placeholder="Email" value={form.email} onChange={e => setForm({...form, email: e.target.value})} />
      <input placeholder="Password" type="password" value={form.password} onChange={e => setForm({...form, password: e.target.value})} />
      <button type="submit">Register</button>
      <div>{msg}</div>
    </form>
  )
}
