import React, { useState } from 'react'
import Login from './pages/Login'
import Register from './pages/Register'
import Dashboard from './pages/Dashboard'

export default function App() {
  const [page, setPage] = useState('login');
  const [token, setToken] = useState(null);

  return (
    <div style={{ padding: 20, fontFamily: 'sans-serif' }}>
      <h2>Backend Assignment Demo</h2>
      <div style={{ marginBottom: 10 }}>
        <button onClick={() => setPage('login')}>Login</button>
        <button onClick={() => setPage('register')}>Register</button>
        <button onClick={() => setPage('dashboard')}>Dashboard</button>
      </div>

      {page === 'login' && <Login onSuccess={(t) => { setToken(t); setPage('dashboard'); }} />}
      {page === 'register' && <Register onSuccess={(t) => { setToken(t); setPage('dashboard'); }} />}
      {page === 'dashboard' && <Dashboard token={token} />}
    </div>
  )
}
