const Task = require('../models/Task.model');

const createTask = async (req, res, next) => {
  try {
    const { title, description } = req.body;
    const task = await Task.create({ title, description, owner: req.user.id });
    res.status(201).json(task);
  } catch (err) { next(err); }
};

const getTasks = async (req, res, next) => {
  try {
    // Admin can view all, user only their own
    let tasks;
    if (req.user.role === 'admin') tasks = await Task.find().populate('owner', 'name email');
    else tasks = await Task.find({ owner: req.user.id });
    res.json(tasks);
  } catch (err) { next(err); }
};

const getTask = async (req, res, next) => {
  try {
    const task = await Task.findById(req.params.id);
    if (!task) return res.status(404).json({ message: 'Not found' });
    if (req.user.role !== 'admin' && task.owner.toString() !== req.user.id) return res.status(403).json({ message: 'Forbidden' });
    res.json(task);
  } catch (err) { next(err); }
};

const updateTask = async (req, res, next) => {
  try {
    const task = await Task.findById(req.params.id);
    if (!task) return res.status(404).json({ message: 'Not found' });
    if (req.user.role !== 'admin' && task.owner.toString() !== req.user.id) return res.status(403).json({ message: 'Forbidden' });

    const { title, description, completed } = req.body;
    task.title = title ?? task.title;
    task.description = description ?? task.description;
    if (typeof completed === 'boolean') task.completed = completed;
    await task.save();
    res.json(task);
  } catch (err) { next(err); }
};

const deleteTask = async (req, res, next) => {
  try {
    const task = await Task.findById(req.params.id);
    if (!task) return res.status(404).json({ message: 'Not found' });
    if (req.user.role !== 'admin' && task.owner.toString() !== req.user.id) return res.status(403).json({ message: 'Forbidden' });
    await task.remove();
    res.json({ message: 'Deleted' });
  } catch (err) { next(err); }
};

module.exports = { createTask, getTasks, getTask, updateTask, deleteTask };
