const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth.middleware');
const taskCtrl = require('../controllers/task.controller');

router.use(auth); // all routes protected

router.post('/', taskCtrl.createTask);
router.get('/', taskCtrl.getTasks);
router.get('/:id', taskCtrl.getTask);
router.put('/:id', taskCtrl.updateTask);
router.delete('/:id', taskCtrl.deleteTask);

module.exports = router;
